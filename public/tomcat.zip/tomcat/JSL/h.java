


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SurveyServlet")
public class SurveyServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:cloudscape://localhost:1527/mydatabase";
    private static final String DB_USER = "user";
    private static final String DB_PASSWORD = "password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String animal = request.getParameter("animal");

        // Update vote count in the database
        updateVoteCount(animal);

        // Generate survey results dynamically
        String surveyResults = generateSurveyResults();

        // Return survey results to the client
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(surveyResults);
    }

    private void updateVoteCount(String animal) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE AnimalSurvey SET Votes = Votes + 1 WHERE Animal = ?")) {
            pstmt.setString(1, animal);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String generateSurveyResults() {
        StringBuilder surveyResults = new StringBuilder();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement("SELECT SUM(Votes) AS TotalVotes FROM AnimalSurvey");
             ResultSet rs = pstmt.executeQuery()) {
            int totalVotes = 0;
            if (rs.next()) {
                totalVotes = rs.getInt("TotalVotes");
            }

            surveyResults.append("<html><head><title>Survey Results</title></head><body>");
            surveyResults.append("<h2>Survey Results</h2>");
            surveyResults.append("<p>Total Responses: ").append(totalVotes).append("</p>");

            pstmt.close();
            rs.close();

            pstmt = conn.prepareStatement("SELECT Animal, Votes FROM AnimalSurvey");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                String animal = rs.getString("Animal");
                int votes = rs.getInt("Votes");
                double votePercentage = (double) votes / totalVotes * 100;
                surveyResults.append("<p>").append(animal).append(": ").append(votes).append(" votes (").append(String.format("%.2f", votePercentage)).append("%)</p>");
            }

            surveyResults.append("</body></html>");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return surveyResults.toString();
    }
}
