
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/RetrieveFormDataServlet")
public class RetrieveFormDataServlet extends HttpServlet {

    @Override
    public void doPost(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Form Data</title></head><body>");
        out.println("<h2>Form Data</h2>");

        // Getting all parameter names
        Enumeration<String> parameterNames = request.getParameterNames();

        // Iterating over parameter names and retrieving values
        while (parameterNames.hasMoreElements()) {
            String paramName = parameterNames.nextElement();
            String paramValue = request.getParameter(paramName);
            out.println("<p><b>" + paramName + ":</b> " + paramValue + "</p>");
        }

        out.println("</body></html>");
        out.close();
    }
}

