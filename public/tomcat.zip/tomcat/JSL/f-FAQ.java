

public class FAQ {
    private int topicID;
    private String question;
    private String answer;

    public FAQ(int topicID, String question, String answer) {
        this.topicID = topicID;
        this.question = question;
        this.answer = answer;
    }

    public int getTopicID() {
        return topicID;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }
}



