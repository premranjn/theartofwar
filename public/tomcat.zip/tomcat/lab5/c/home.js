function Power (x1, y1) {
    return x1**y1
}



button = document.querySelector('.submit');

button.addEventListener('click',(e)=>{
    e.preventDefault()
    x1=document.querySelector(".x1")
    y1=document.querySelector(".y1")
 
    document.querySelector('.ans').textContent=" Answer is : "+Power(x1.value, y1.value);
})