function Check_Prime_root(x1){
    if(x1<2){
        return false;
    }
    for(let i=3; i<x1**0.5; i++){
        if(x1%i==0) return false;
    }
    return true;
}
function Check_Prime_half(x1){
    if(x1<2){
        return false;
    }
    for(let i=3; i<x1*0.5; i++){
        if(x1%i==0) return false;
    }
    return true;
}



button = document.querySelector('.submit');

button.addEventListener('click',(e)=>{
    e.preventDefault()
  
    start_root = performance.now()
    for(let i=1; i<10000; i++){
        Check_Prime_root(i)
    }
    end_root = performance.now()
    start_half = performance.now()
    for(let i=1; i<10000; i++){
        Check_Prime_half(i)
    }
    end_half=performance.now()
    time_root = end_root - start_root
    time_half = end_half - start_half
    document.querySelector('.ans1').textContent = "time taken for root = "+time_root
    document.querySelector('.ans2').textContent = "time taken for half = "+time_half
})