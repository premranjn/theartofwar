function Check_Armstrong(x){
    const numString = x.toString()
    const numDigits = numString.length;
    let sum=0;
    for(let digit of numString){
        sum+=parseInt(digit)**numDigits
    }
    return sum==x
}



button = document.querySelector('.submit');

button.addEventListener('click',(e)=>{
    e.preventDefault()
    ans = document.querySelector('.ans')
    for(let i=100; i<5000; i++){
        if(Check_Armstrong(i)){
            ans.textContent += i + " ";
        }
    }
})