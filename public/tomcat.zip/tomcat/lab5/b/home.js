function Compute_Distance (x1, y1, x2, y2) {
    return ((x1-x2)**2 + (y1-y2)**2 ) ** 0.5
}



button = document.querySelector('.submit');

button.addEventListener('click',(e)=>{
    e.preventDefault()
    x1=document.querySelector(".x1")
    y1=document.querySelector(".y1")
    x2=document.querySelector(".x2")
    y2=document.querySelector(".y2")
    document.querySelector('.ans').textContent=" Distance between points is : "+Compute_Distance(x1.value, y1.value, x2.value, y2.value);
})