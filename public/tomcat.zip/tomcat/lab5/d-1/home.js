function Check_Prime(x1){
    if(x1<2){
        return false;
    }
    for(let i=3; i<x1**0.5; i++){
        if(x1%i==0) return false;
    }
    return true;
}



button = document.querySelector('.submit');

button.addEventListener('click',(e)=>{
    e.preventDefault()
    x1=document.querySelector(".x1").value
 
    if(Check_Prime(x1)){
        document.querySelector('.ans').textContent=x1+" is Prime";
    }
    else{
        document.querySelector('.ans').textContent=x1+" is not Prime";
    }
})