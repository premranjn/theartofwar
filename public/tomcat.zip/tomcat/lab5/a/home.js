function Sphere_Volume (r) {
    return 3/4 * 3.14 * (r ** 3)
}

function Circle_Area (r) {
    return 3.14 * (r ** 2);
}


button = document.querySelector('.submit');
radius = document.querySelector('.radius');

button.addEventListener('click',(e)=>{
    e.preventDefault()
    r = radius.value;
    document.querySelector('.ans1').textContent=" Area of circle is : "+Circle_Area(r);
    document.querySelector('.ans2').textContent="Volume of sphere is : "+Sphere_Volume(r)
})