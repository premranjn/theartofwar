function Check_Prime(x1){
    if(x1<2){
        return false;
    }
    for(let i=3; i<x1**0.5; i++){
        if(x1%i==0) return false;
    }
    return true;
}



button = document.querySelector('.submit');

button.addEventListener('click',(e)=>{
    e.preventDefault()
    ans = document.querySelector('.ans')
    for(let i=1; i<1000; i++){
        if(Check_Prime(i)){
            ans.textContent += i + " ";
        }
    }
})