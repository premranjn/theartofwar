function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// Function to generate a random font size
function getRandomFontSize() {
  return Math.floor(Math.random() * 30) + 10 + "px"; // Range: 10px to 40px
}

// Function to move text randomly on the webpage
function moveTextRandomly() {
  var text = document.getElementById("movingText");
  var maxX = window.innerWidth - text.offsetWidth;
  var maxY = window.innerHeight - text.offsetHeight;
  var newX = Math.floor(Math.random() * maxX);
  var newY = Math.floor(Math.random() * maxY);
  var newColor = getRandomColor();
  var newSize = getRandomFontSize();

  text.style.left = newX + "px";
  text.style.top = newY + "px";
  text.style.color = newColor;
  text.style.fontSize = newSize;
}

// Call moveTextRandomly every second
setInterval(moveTextRandomly, 1000);

// Track mouse movement and display element name and (X,Y) coordinates
document.addEventListener("mousemove", function(event) {
  var x = event.clientX;
  var y = event.clientY;
  var elementMouseIsOver = document.elementFromPoint(x, y);
  var elementName = elementMouseIsOver.tagName;
    document.getElementById("content").textContent = ("Element: " + elementName + ", Coordinates: (" + x + ", " + y + ")");
});
