function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

function getRandomFontSize() {
  return Math.floor(Math.random() * 30) + 10 + "px"; // Range: 10px to 40px
}

function moveTextRandomly() {
  var text = document.getElementById("movingText");
  var maxX = window.innerWidth - text.offsetWidth;
  var maxY = window.innerHeight - text.offsetHeight;
  var newX = Math.floor(Math.random() * maxX);
  var newY = Math.floor(Math.random() * maxY);
  var newColor = getRandomColor();
  var newSize = getRandomFontSize();

  text.style.left = newX + "px";
  text.style.top = newY + "px";
  text.style.color = newColor;
  text.style.fontSize = newSize;
}

// Call moveTextRandomly every second
setInterval(moveTextRandomly, 1000);
