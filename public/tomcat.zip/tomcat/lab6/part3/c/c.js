function generateThreeLetterWords() {
    var fiveLetterWord = document.getElementById("fiveLetterWord").value;
    var threeLetterWords = [];

    if (fiveLetterWord.length === 5) {
        for (var i = 0; i < 5; i++) {
            for (var j = 0; j < 5; j++) {
                for (var k = 0; k < 5; k++) {
                    if (i !== j && i !== k && j !== k) {
                        var threeLetterWord = fiveLetterWord[i] + fiveLetterWord[j] + fiveLetterWord[k];
                        threeLetterWords.push(threeLetterWord);
                    }
                }
            }
        }

        document.getElementById("result").innerHTML = threeLetterWords.join(" ");
    } else {
        document.getElementById("result").innerHTML = "Please enter a five-letter word.";
    }
}