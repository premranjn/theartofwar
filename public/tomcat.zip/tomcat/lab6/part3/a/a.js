function searchSubstring() {
    var str = document.getElementById("inputString").value;
    var substring = document.getElementById("inputSubstring").value;
    var index = str.indexOf(substring);
    var index2 =-1
    for(let i=0; i<str.length; i++){
        if(str[i]==substring[0]){
            var flag=true;
            for(let j=1; j<substring.length; j++){
                if(str[i+j]!=substring[j]){
                    flag=false;
                    break;
                }
            }
            if(flag){
                index2 = i;
                break;
            }
        }
    }
    if (index !== -1) {
        document.getElementById("searchResult").innerHTML = "Substring found at index using string methods: " + index + " <br /> Substring found at index without using string methods: "+index2;
    } else {
        document.getElementById("searchResult").innerHTML = "Substring not found";
    }
}

function getCharacter() {
    var str = document.getElementById("inputString").value;
    var index = parseInt(document.getElementById("inputIndex").value);
    if (index >= 0 && index < str.length) {
        document.getElementById("characterResult").innerHTML = "Character at index " + index + " using string method: " + str.charAt(index) + "<br />  Character at index " + index + " without using string method: "+str[index];
    } else {
        document.getElementById("characterResult").innerHTML = "Invalid index";
    }
}

function concatenateStrings() {
    var str1 = document.getElementById("inputString1").value;
    var str2 = document.getElementById("inputString2").value;
    var result = str1.concat(str2);
    var result2 ="";
    for(let i=0;i<str1.length;i++) result2 += str1[i];
    for(let i=0;i<str2.length;i++) result2 += str2[i];
    document.getElementById("concatenationResult").innerHTML = "Concatenated string using string method : " + result + " <br /> Concatenated string not using string method :"+result2;
}