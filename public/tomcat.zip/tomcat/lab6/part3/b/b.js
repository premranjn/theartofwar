function convertText() {
    var inputText = document.getElementById("inputText").value;
    var upperCaseText = inputText.toUpperCase();
    var lowerCaseText = inputText.toLowerCase();
    
    document.getElementById("upperCaseOutput").innerHTML = "Upper Case: " + upperCaseText;
    document.getElementById("lowerCaseOutput").innerHTML = "Lower Case: " + lowerCaseText;
}