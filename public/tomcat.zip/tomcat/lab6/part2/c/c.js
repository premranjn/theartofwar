function binarySearch() {
    var elements = document.getElementById("elements").value.split(",");
    var key = parseInt(document.getElementById("key").value);

    elements = elements.map(function(item) {
        return parseInt(item);
    });

    var low = 0;
    var high = elements.length - 1;
    var found = false;
    var index = -1;

    while (low <= high) {
        var mid = Math.floor((low + high) / 2);

        if (elements[mid] === key) {
            found = true;
            index = mid;
            break;
        } else if (elements[mid] < key) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    // Display the search result
    var result = document.getElementById("result");
    if (found) {
        result.value = "FOUND at index " + index;
    } else {
        result.value = "NOT FOUND";
    }
}