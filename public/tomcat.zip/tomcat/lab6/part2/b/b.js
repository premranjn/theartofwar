function calculateDates() {
    var currentDate = new Date();
    
    
        var previousDate = new Date(currentDate);
        previousDate.setDate(currentDate.getDate() - 7);
        

    
        var futureDate = new Date(currentDate);
        futureDate.setDate(currentDate.getDate() + 7);
        

    var output = "";
    
    output += "Previous Date: " + previousDate.getDate() + " " + getMonthName(previousDate.getMonth()) + " " + previousDate.getFullYear() + "<br>";
    
    output += "<br>";
    
    output += "Future Date: " + futureDate.getDate() + " " + getMonthName(futureDate.getMonth()) + " " + futureDate.getFullYear() + "<br>";
    

    document.getElementById("result").innerHTML = output;
}

function calculateAge() {
    var dob = new Date(document.getElementById("dob").value);
    var currentDate = new Date();

    var years = currentDate.getFullYear() - dob.getFullYear();
    var months = currentDate.getMonth() - dob.getMonth();
    var days = currentDate.getDate() - dob.getDate();

    if (months < 0 || (months === 0 && days < 0)) {
        years--;
        months += 12;
    }

    if (days < 0) {
        var previousMonthDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 0);
        days += previousMonthDate.getDate();
        months--;
    }

    document.getElementById("age").innerHTML = "Age: " + years + " Years, " + months + " Months, " + days + " Days";
}

function getMonthName(month) {
    var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return monthNames[month];
}