
function sortStrings() {
    var inputStrings = document.getElementById("inputStrings").value.split(",");
    var sortedStrings = inputStrings.sort();
    var stringsStartingWithE = sortedStrings.filter(function(string) {
        return string.charAt(0).toLowerCase() === 'e';
    });

    document.getElementById("sortedOutput").innerHTML = "Sorted Strings: " + sortedStrings.join(", ");
    document.getElementById("eStringsOutput").innerHTML = "Strings starting with 'e': " + stringsStartingWithE.join(", ");
}