function countWords() {
    var text = document.getElementById("textArea").value;
    var words = text.split(/\s+/);
    var wordCount = {};

    for (var i = 0; i < words.length; i++) {
        var word = words[i].replace(/[^\w\s]|_/g, "").toLowerCase();
        var length = word.length;

        if (length > 0) {
            if (!wordCount[length]) {
                wordCount[length] = 0;
            }
            wordCount[length]++;
        }
    }

    var table = document.getElementById("wordCountTable");
    for (var length in wordCount) {
        var count = wordCount[length];
        var row = table.insertRow();
        var lengthCell = row.insertCell();
        var countCell = row.insertCell();
        lengthCell.innerHTML = length;
        countCell.innerHTML = count;
    }
}