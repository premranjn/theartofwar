function searchLastOccurrence() {
    var str = document.getElementById("inputString").value;
    var substring = document.getElementById("searchSubstring").value;
    
    var lastIndex = str.lastIndexOf(substring);
    
    var lastIndex2 =-1
    for(let i=0; i<str.length; i++){
        if(str[i]==substring[0]){
            var flag=true;
            for(let j=1; j<substring.length; j++){
                if(str[i+j]!=substring[j]){
                    flag=false;
                    break;
                }
            }
            if(flag){
                lastIndex2 = i;
            }
        }
    }
    if(lastIndex == -1){
        alert("Occurence not found")
    }
    else {
        alert("Last occurrence index: " + lastIndex + " using string method, \n and "+ lastIndex2 + " without using string method");
    }
}

function extractSubstring() {
    var str = document.getElementById("inputString").value;
    var start = parseInt(document.getElementById("startPosition").value);
    var end = parseInt(document.getElementById("endPosition").value);
    
    var substring = str.slice(start, end);

    var substring2 = "";
    for(let i=start; i<end; i++)
        substring2 += str[i];
    
    alert("Extracted substring: " + substring + " using string method, \n and "+ substring2 + " without using string method");
}

function splitString() {
    var str = document.getElementById("inputString").value;
    var delimiter = document.getElementById("splitDelimiter").value;
    
    var substrings = str.split(delimiter);

    var substrings2 = [];
    var cur=""
    for(let i=0; i<str.length; i++){
        if(str[i] == delimiter){
            substrings2.push(cur)
            cur="";
        }else{
            cur+=str[i];
        }
    }
    if(str[str.length-1]!=delimiter)substrings2.push(cur);
    
    alert("Split substrings: " + substrings+ " using string method, \n and "+ substrings2.join(",") + " without using string method");
}

function resetForm() {
    document.getElementById("inputString").value = "";
    document.getElementById("searchSubstring").value = "";
    document.getElementById("startPosition").value = "";
    document.getElementById("endPosition").value = "";
    document.getElementById("splitDelimiter").value = "";
}