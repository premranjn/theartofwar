import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RetrieveColorServlet");
public class RetrieveColorServlet extends HttpServlet{
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
        res.setContentType("text/HTML");
        PrintWriter out = res.getWriter();

        //get parameter
        String parval = req.getParameter("color");

        out.println("<html><head></head><body>");
        out.println("<p>you selected" + parval + "</p></body></html>");
        out.close();
    }
}











































// import java.io.IOException;
// import java.io.PrintWriter;
// import javax.servlet.ServletException;
// import javax.servlet.annotation.WebServlet;
// import javax.servlet.http.HttpServlet;
// import javax.servlet.http.HttpServletRequest;
// import javax.servlet.http.HttpServletResponse;

// @WebServlet("/RetrieveColorServlet")
// public class RetrieveColorServlet extends HttpServlet {

//     @Override
//     protected void doGet(HttpServletRequest request, HttpServletResponse response)
//             throws ServletException, IOException {
//         response.setContentType("text/html");
//         PrintWriter out = response.getWriter();

//         String selectedColor = request.getParameter("color");

//         out.println("<html><head><title>Selected Color</title></head><body>");
//         out.println("<h2>Selected Color</h2>");
//         out.println("<p>You selected: " + selectedColor + "</p>");
//         out.println("</body></html>");

//         out.close();
//     }
// }
