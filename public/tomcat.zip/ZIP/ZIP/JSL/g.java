
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(); // Get the HttpSession object

        // Retrieve selected language from the request
        String language = request.getParameter("language");

        // Add language and book ISBN to the session
        session.setAttribute("language", language);
        session.setAttribute("bookISBN", getBookISBN(language));

        // Display session information
        out.println("<html><head><title>Session Information</title></head><body>");
        out.println("<h2>Session Information</h2>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<p>Session Creation Time: " + session.getCreationTime() + "</p>");
        out.println("<p>Session Last Accessed Time: " + session.getLastAccessedTime() + "</p>");
        out.println("<p>Session Max Inactive Interval: " + session.getMaxInactiveInterval() + " seconds</p>");
        out.println("<p>Session is New: " + session.isNew() + "</p>");
        out.println("<p>Selected Language: " + language + "</p>");
        out.println("<p>Recommended Book ISBN: " + session.getAttribute("bookISBN") + "</p>");
        out.println("</body></html>");
    }

    private String getBookISBN(String language) {
        // Mock method to return ISBN based on selected language
        switch (language) {
            case "C":
                return "9780131103627";
            case "C++":
                return "9780133574849";
            case "Java":
                return "9780134685991";
            case "VB 6":
                return "9781572315482";
            default:
                return "N/A";
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}


