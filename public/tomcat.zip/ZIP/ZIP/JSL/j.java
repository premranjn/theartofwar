
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CheckboxServlet")
public class CheckboxServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve selected fruits from request parameters
        String[] selectedFruits = request.getParameterValues("fruits");

        // Start building HTML response
        out.println("<html><head><title>Selected Fruits</title></head><body>");
        out.println("<h2>Selected Fruits</h2>");

        if (selectedFruits != null && selectedFruits.length > 0) {
            // If at least one fruit is selected, display them
            out.println("<ul>");
            for (String fruit : selectedFruits) {
                out.println("<li>" + fruit + "</li>");
            }
            out.println("</ul>");
        } else {
            // If no fruit is selected, display a message
            out.println("<p>No fruits selected.</p>");
        }

        // Close HTML response
        out.println("</body></html>");
    }
}