
public class Topic {
    private int topicID;
    private String topicName;

    public Topic(int topicID, String topicName) {
        this.topicID = topicID;
        this.topicName = topicName;
    }

    public int getTopicID() {
        return topicID;
    }

    public String getTopicName() {
        return topicName;
    }
}
