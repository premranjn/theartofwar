

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookRecommendationsServlet")
public class BookRecommendationsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        String language = "";
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("favoriteLanguage")) {
                    language = cookie.getValue();
                    break;
                }
            }
        }

        // Some sample book recommendations based on selected language
        String[] recommendations = {};
        if (language.equals("C")) {
            recommendations = new String[]{"The C Programming Language by Kernighan and Ritchie", "C Programming Absolute Beginner's Guide by Greg Perry"};
        } else if (language.equals("C++")) {
            recommendations = new String[]{"C++ Primer by Stanley B. Lippman", "Accelerated C++: Practical Programming by Example by Andrew Koenig"};
        } else if (language.equals("Java")) {
            recommendations = new String[]{"Head First Java by Kathy Sierra and Bert Bates", "Effective Java by Joshua Bloch"};
        } else if (language.equals("VB 6")) {
            recommendations = new String[]{"VB6: Eat Vegan Before 6: 00 to Lose Weight and Restore Your Health . . . for Good by Mark Bittman"};
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Book Recommendations</title></head><body>");
        out.println("<h2>Book Recommendations for " + language + "</h2>");
        out.println("<ul>");
        for (String book : recommendations) {
            out.println("<li>" + book + "</li>");
        }
        out.println("</ul>");
        out.println("</body></html>");
    }
}

