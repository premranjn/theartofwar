
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FAQServlet")
public class FAQServlet extends HttpServlet {

    private List<Topic> topics;
    private Map<Integer, List<FAQ>> faqs;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize topics and FAQs
        initializeData();
    }

    private void initializeData() {
        topics = new ArrayList<>();
        faqs = new HashMap<>();

        // Sample data
        topics.add(new Topic(1, "General"));
        topics.add(new Topic(2, "Technical"));

        List<FAQ> generalFAQs = new ArrayList<>();
        generalFAQs.add(new FAQ(1, "What is this website about?", "This website is a dynamic FAQ application."));
        generalFAQs.add(new FAQ(1, "How can I contact support?", "You can contact support by emailing support@example.com."));

        List<FAQ> technicalFAQs = new ArrayList<>();
        technicalFAQs.add(new FAQ(2, "What programming languages are used?", "This website is built using Java Servlets."));

        faqs.put(1, generalFAQs);
        faqs.put(2, technicalFAQs);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>FAQs</title></head><body>");
        out.println("<h1>FAQs</h1>");

        for (Topic topic : topics) {
            out.println("<h2>" + topic.getTopicName() + "</h2>");
            List<FAQ> topicFAQs = faqs.get(topic.getTopicID());
            if (topicFAQs != null) {
                for (FAQ faq : topicFAQs) {
                    out.println("<p><strong>Q: " + faq.getQuestion() + "</strong><br/>A: " + faq.getAnswer() + "</p>");
                }
            }
        }

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
