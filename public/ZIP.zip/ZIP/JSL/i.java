
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SurveyServlet")
public class SurveyServlet extends HttpServlet {

    private Map<String, Integer> voteCounts;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize vote counts for each animal
        initializeVoteCounts();
    }

    private void initializeVoteCounts() {
        voteCounts = new HashMap<>();
        voteCounts.put("Dog", 0);
        voteCounts.put("Cat", 0);
        voteCounts.put("Parrot", 0);
        voteCounts.put("Cow", 0);
        voteCounts.put("None", 0);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String animal = request.getParameter("animal");

        // Update vote count in the list
        if (voteCounts.containsKey(animal)) {
            int currentVotes = voteCounts.get(animal);
            voteCounts.put(animal, currentVotes + 1);
        }

        // Generate survey results dynamically
        String surveyResults = generateSurveyResults();

        // Return survey results to the client
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(surveyResults);
    }

    private String generateSurveyResults() {
        StringBuilder surveyResults = new StringBuilder();
        int totalVotes = 0;
        for (int votes : voteCounts.values()) {
            totalVotes += votes;
        }

        surveyResults.append("<html><head><title>Survey Results</title></head><body>");
        surveyResults.append("<h2>Survey Results</h2>");
        surveyResults.append("<p>Total Responses: ").append(totalVotes).append("</p>");

        for (Map.Entry<String, Integer> entry : voteCounts.entrySet()) {
            String animal = entry.getKey();
            int votes = entry.getValue();
            double votePercentage = (double) votes / totalVotes * 100;
            surveyResults.append("<p>").append(animal).append(": ").append(votes).append(" votes (").append(String.format("%.2f", votePercentage)).append("%)</p>");
        }

        surveyResults.append("</body></html>");

        return surveyResults.toString();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

