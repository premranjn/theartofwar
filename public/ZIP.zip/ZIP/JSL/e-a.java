

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CookieServlet")
public class CookieServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        String language = "";
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("favoriteLanguage")) {
                    language = cookie.getValue();
                    break;
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Book Recommendations</title></head><body>");
        if (!language.isEmpty()) {
            out.println("<h2>Your favorite programming language is: " + language + "</h2>");
            out.println("<a href='BookRecommendationsServlet'>View Book Recommendations</a>");
        } else {
            out.println("<h2>Please select your favorite programming language</h2>");
            out.println("<a href='CookieSelectLanguage.html'>Go back to select language</a>");
        }
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String language = request.getParameter("language");
        Cookie cookie = new Cookie("favoriteLanguage", language);
        cookie.setMaxAge(30 * 24 * 60 * 60); // Cookie expires in 30 days
        response.addCookie(cookie);
        response.sendRedirect("CookieServlet");
    }
}

